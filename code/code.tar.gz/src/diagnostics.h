#ifndef DIAGNOSTICS
#include <stdio.h>
#define DIAGNOSTICS printf
#endif
