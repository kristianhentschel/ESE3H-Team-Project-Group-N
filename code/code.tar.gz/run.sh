#!/bin/sh
cd htdocs
../bin/master_webserver
