#!/bin/sh
cd src/
make clean all

